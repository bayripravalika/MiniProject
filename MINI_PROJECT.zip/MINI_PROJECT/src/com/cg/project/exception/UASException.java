package com.cg.project.exception;

public class UASException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UASException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UASException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	
}
